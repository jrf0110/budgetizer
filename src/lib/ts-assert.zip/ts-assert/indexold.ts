import { AssertionError } from './assertion-error'

export class ActionBuilder<T> {
  public curr: any
  public actions: Action[] = []

  constructor(value?: T) {
    this.curr = value
  }

  evaluate(): T {
    return this.actions.reduce<T>((current: T, action: Action, i) => {
      return action.evaluate(current)
    }, this.curr)
  }
}

export class AssertionBuilder<T> extends ActionBuilder<T> {
  public static equals<T>(a: T, b: T) {
    return new AssertionBuilder<T>(a).equals(b)
  }

  public static errorActionMap = new WeakMap<ActionConstructor, ErrorConstructor>()

  equals(value: T) {
    this.actions.push(new EqualsAction<T>(value))
    return this
  }

  doesThrow() {
    const prevAction = this.actions[this.actions.length - 1]

    // this.actions.push(new DoesThrowAction)
  }
}

export abstract class Action {
  abstract evaluate(...args: any[]): any
}

interface ErrorConstructor {
  new (message?: string): Error
}

interface ActionConstructor {
  new (): Action
}

// export class ActionConstructor extends Constructor{}

export class EqualsAction<T> extends Action {
  public a: T

  constructor(a: T) {
    super()
    this.a = a
  }

  evaluate(b: T): boolean {
    return this.a === b
  }
}

export class DoesThrowAction<T> extends Action {
  public error: Error

  constructor(error: Error) {
    super()
    this.error = error
  }

  evaluate(prevVal: any): any {
    if (!prevVal) {
      throw this.error
    }

    return prevVal
  }
}

// new Assertion<number>().equals(1, 2)
// const doesEqual = chain(123)
//   .add(234)
//   .equals(357)

AssertionBuilder.errorActionMap.set(Action, Error)