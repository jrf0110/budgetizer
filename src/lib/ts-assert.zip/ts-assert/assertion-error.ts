export class AssertionError extends Error {

}